
[![DOI](https://zenodo.org/badge/doi/10.5281/zenodo.14547.svg)](http://dx.doi.org/10.5281/zenodo.14547)

> **Note:** since I retired a few months ago I do not really maintain this package any more. I would be more than happy if an interested party was interested to take over. In the meantime, I have "archived" the repository to clearly signal that there is no maintenance. I would be happy to unarchive it and transfer ownership if someone is interested.    
> [@iherman](https://github.com/iherman)

> **This new version 3.6.0 is now built and maintained on [pyRdfa3](https://prrvchr.github.io/pyrdfa3/)**

For now, the package can only be installed from [TestPyPI](https://test.pypi.org/manage/project/pyRdfa3/releases/) with command `pip install --index-url https://test.pypi.org/simple/ pyRdfa3`.

PyRDFA
======


What is it
----------

pyRdfa distiller/parser library. The distribution contains:

- ./pyRdfa: the Python library. You should copy the directory somewhere into your PYTHONPATH.
  Alternatively, you can also install from [Test Python Package Index](https://test.pypi.org/manage/project/pyRdfa3/releases/) with command:

    `pip install --index-url https://test.pypi.org/simple/ pyRdfa3`

- ./scripts/CGI_RDFa.py: can be used as a CGI script to invoke the library.
  It has to be adapted to the local server setup, namely in setting the right paths

- ./scripts/localRdfa.py: script that can be run locally on to transform
  a file into RDF (on the standard output). Run the script with "-h" to
  get the available flags.

- ./doc: (pdoc) documentation of the classes and functions

The package primarily depends on:
- Python version 3.7 or higher
- [rdflib](https://pypi.org/project/rdflib/7.0.0/): version 7.0.0 or higher is strongly recommended.
- [html5lib](https://pypi.org/project/html5lib/1.1/): version 1.1 or higher is strongly recommended.

The package has been tested on Python version 3.7 and higher (no more support for Python 2.x).

For the details on RDFa 1.1, see:

- <http://www.w3.org/TR/rdfa-core>
- <http://www.w3.org/TR/rdfa-lite/>
- <http://www.w3.org/TR/xhtml-rdfa/>
- <http://www.w3.org/TR/rdfa-in-html/>

possibly:

- <http://www.w3.org/TR/rdfa-primer/>
